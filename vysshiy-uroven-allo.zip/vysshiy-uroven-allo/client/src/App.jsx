import { useEffect, useMemo, useState } from "react";
import {
  LiveKitRoom,
  VideoConference,
  RoomAudioRenderer,
  StartAudio
} from "@livekit/components-react";

function makeRoomCode() {
  return Math.random().toString(36).slice(2, 10);
}

function readRoomFromUrl() {
  return new URLSearchParams(window.location.search).get("room") || "";
}

export default function App() {
  const [roomId, setRoomId] = useState(readRoomFromUrl);
  const [name, setName] = useState(localStorage.getItem("allo-name") || "");
  const [nameDraft, setNameDraft] = useState(name);
  const [joinCode, setJoinCode] = useState(readRoomFromUrl());
  const [tokenInfo, setTokenInfo] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [recent, setRecent] = useState(() => {
    try { return JSON.parse(localStorage.getItem("allo-recent") || "[]"); }
    catch { return []; }
  });

  const meetingLink = useMemo(() => {
    if (!roomId) return "";
    return `${window.location.origin}${window.location.pathname}?room=${encodeURIComponent(roomId)}`;
  }, [roomId]);

  useEffect(() => {
    const onPop = () => {
      const id = readRoomFromUrl();
      setRoomId(id);
      setJoinCode(id);
      setTokenInfo(null);
    };
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);

  async function enterRoom(id, participantName) {
    const cleanId = id.trim().replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 48);
    const cleanName = participantName.trim().slice(0, 40);
    if (!cleanId) return setError("Укажите код конференции.");
    if (!cleanName) return setError("Введите имя, которое увидят участники.");

    setError("");
    setLoading(true);
    try {
      const response = await fetch("/api/token", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ room: cleanId, name: cleanName })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Не удалось подключиться.");
      localStorage.setItem("allo-name", cleanName);
      setName(cleanName);
      setNameDraft(cleanName);
      const nextRecent = [cleanId, ...recent.filter((x) => x !== cleanId)].slice(0, 5);
      setRecent(nextRecent);
      localStorage.setItem("allo-recent", JSON.stringify(nextRecent));
      window.history.pushState({}, "", `?room=${encodeURIComponent(cleanId)}`);
      setRoomId(cleanId);
      setTokenInfo(data);
    } catch (e) {
      setError(e.message || "Ошибка подключения.");
    } finally {
      setLoading(false);
    }
  }

  function createMeeting() {
    const id = makeRoomCode();
    setJoinCode(id);
    enterRoom(id, nameDraft || name);
  }

  async function copyLink() {
    try {
      await navigator.clipboard.writeText(meetingLink);
      setError("");
      alert("Ссылка-приглашение скопирована.");
    } catch {
      window.prompt("Скопируйте ссылку на конференцию:", meetingLink);
    }
  }

  function leaveMeeting() {
    setTokenInfo(null);
    setRoomId("");
    setJoinCode("");
    window.history.pushState({}, "", window.location.pathname);
  }

  if (roomId && tokenInfo) {
    return (
      <div className="meeting-shell">
        <header className="meeting-topbar">
          <a className="brand compact" href="/" onClick={(e) => { e.preventDefault(); leaveMeeting(); }}>
            <span className="brand-mark">А</span>
            <span>Высший уровень: <b>Алло</b></span>
          </a>
          <div className="meeting-top-actions">
            <span className="live-indicator"><i /> Встреча активна</span>
            <button className="small-outline" onClick={copyLink}>Скопировать приглашение</button>
            <button className="small-danger" onClick={leaveMeeting}>Выйти</button>
          </div>
        </header>
        <div className="conference-area">
          <LiveKitRoom
            token={tokenInfo.token}
            serverUrl={tokenInfo.url}
            connect={true}
            audio={true}
            video={true}
            onDisconnected={leaveMeeting}
            data-lk-theme="default"
            style={{ height: "100%" }}
          >
            <VideoConference />
            <RoomAudioRenderer />
            <StartAudio label="Нажмите, чтобы включить звук" />
          </LiveKitRoom>
        </div>
      </div>
    );
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="/">
          <span className="brand-mark">А</span>
          <span>Высший уровень: <b>Алло</b></span>
        </a>
        <div className="top-note"><i /> Ваше пространство для общения</div>
      </header>

      <main className="main-content">
        <section className="hero">
          <div className="eyebrow"><span>✦</span> ЛИЧНЫЕ ВИДЕОКОНФЕРЕНЦИИ</div>
          <h1>Будьте ближе.<br /><span>Несмотря на расстояние.</span></h1>
          <p className="subtitle">
            Создавайте встречи, приглашайте близких и общайтесь<br className="desktop-break" />
            в комфортном пространстве без лишнего.
          </p>

          <div className="meeting-panel">
            <label className="field-label" htmlFor="display-name">Как вас называть?</label>
            <input
              id="display-name"
              className="text-input name-input"
              value={nameDraft}
              onChange={(e) => setNameDraft(e.target.value)}
              placeholder="Ваше имя"
              maxLength={40}
            />
            <button className="primary-button" onClick={createMeeting} disabled={loading}>
              <span className="plus">＋</span>
              {loading ? "Подключаем..." : "Создать конференцию"}
            </button>
            <div className="separator"><span>или присоединиться</span></div>
            <div className="join-row">
              <input
                className="text-input"
                value={joinCode}
                onChange={(e) => setJoinCode(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && enterRoom(joinCode, nameDraft || name)}
                placeholder="Вставьте ссылку или код встречи"
              />
              <button className="join-button" disabled={loading} onClick={() => {
                let code = joinCode.trim();
                try {
                  if (code.startsWith("http")) code = new URL(code).searchParams.get("room") || "";
                } catch { code = ""; }
                enterRoom(code, nameDraft || name);
              }}>Войти <span>→</span></button>
            </div>
            {error && <div className="error-message" role="alert">{error}</div>}
            <p className="privacy-note"><span>◇</span> Подключайтесь только по приглашению</p>
          </div>
        </section>

        <section className="feature-grid">
          <article className="feature-card">
            <div className="feature-icon">◉</div>
            <h3>Живое общение</h3>
            <p>Видео и звук для разговоров лицом к лицу.</p>
          </article>
          <article className="feature-card">
            <div className="feature-icon">↗</div>
            <h3>Одно приглашение</h3>
            <p>Отправьте ссылку — и участники смогут войти.</p>
          </article>
          <article className="feature-card">
            <div className="feature-icon">✧</div>
            <h3>Всё необходимое</h3>
            <p>Экран, чат и управление участниками в комнате.</p>
          </article>
        </section>

        {recent.length > 0 && (
          <section className="recent-section">
            <div className="section-heading">
              <h2>Недавние конференции</h2>
              <span>На этом устройстве</span>
            </div>
            {recent.map((id) => (
              <button className="recent-row" key={id} onClick={() => setJoinCode(id)}>
                <span className="recent-symbol">▦</span>
                <span>Комната <b>{id}</b></span>
                <span className="recent-open">Вставить код →</span>
              </button>
            ))}
          </section>
        )}
      </main>

      <footer className="footer">
        <span>© 2026 Высший уровень: Алло</span>
        <span>На связи. На высшем уровне.</span>
      </footer>
    </div>
  );
}
