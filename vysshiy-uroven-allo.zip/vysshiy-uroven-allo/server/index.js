import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import { AccessToken } from "livekit-server-sdk";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export function createApp() {
  const app = express();
  app.use(cors());
  app.use(express.json({ limit: "20kb" }));

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, service: "Высший уровень: Алло" });
  });

  app.post("/api/token", async (req, res) => {
    try {
      const { room, name } = req.body || {};
      if (!room || !name || typeof room !== "string" || typeof name !== "string") {
        return res.status(400).json({ error: "Нужны код конференции и имя участника." });
      }
      if (!process.env.LIVEKIT_URL || !process.env.LIVEKIT_API_KEY || !process.env.LIVEKIT_API_SECRET) {
        return res.status(503).json({
          error: "Видеосервер ещё не настроен. Добавьте LIVEKIT_URL, LIVEKIT_API_KEY и LIVEKIT_API_SECRET в файл .env."
        });
      }

      const safeRoom = room.trim().replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 48);
      const safeName = name.trim().replace(/[<>]/g, "").slice(0, 40);
      if (!safeRoom || !safeName) {
        return res.status(400).json({ error: "Проверьте код конференции и имя." });
      }

      const identity = `${safeName}-${cryptoRandomId()}`;
      const token = new AccessToken(process.env.LIVEKIT_API_KEY, process.env.LIVEKIT_API_SECRET, {
        identity,
        name: safeName,
        ttl: "2h"
      });
      token.addGrant({
        roomJoin: true,
        room: safeRoom,
        canPublish: true,
        canSubscribe: true,
        canPublishData: true
      });

      return res.json({ token: await token.toJwt(), url: process.env.LIVEKIT_URL, room: safeRoom, name: safeName });
    } catch (error) {
      console.error("Token error:", error);
      return res.status(500).json({ error: "Не удалось подготовить подключение." });
    }
  });

  const clientDist = path.resolve(__dirname, "../client/dist");
  app.use(express.static(clientDist));
  app.get("*", (_req, res) => {
    res.sendFile(path.join(clientDist, "index.html"), (err) => {
      if (err) res.status(404).send("Сначала соберите клиент командой npm run build.");
    });
  });
  return app;
}

export function startServer(port = Number(process.env.PORT || 3001), host = "127.0.0.1") {
  return new Promise((resolve, reject) => {
    const server = createApp().listen(port, host);
    server.once("listening", () => resolve(server));
    server.once("error", reject);
  });
}

function cryptoRandomId() {
  return Math.random().toString(36).slice(2, 9);
}

if (process.env.ALLO_STANDALONE_SERVER === "1") {
  startServer().then((server) => {
    const address = server.address();
    console.log(`Алло: сервер запущен на http://${address.address}:${address.port}`);
  }).catch((error) => {
    console.error("Не удалось запустить сервер:", error);
    process.exit(1);
  });
}
