import { app, BrowserWindow, shell, dialog } from "electron";
import path from "node:path";
import fs from "node:fs";
import dotenv from "dotenv";
import { fileURLToPath } from "node:url";
import { startServer } from "../server/index.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
let localServer;
let mainWindow;

async function loadUserConfig() {
  const configPath = path.join(app.getPath("userData"), ".env");
  if (!fs.existsSync(configPath)) {
    fs.mkdirSync(path.dirname(configPath), { recursive: true });
    fs.writeFileSync(configPath,
      "LIVEKIT_URL=wss://YOUR-PROJECT.livekit.cloud\nLIVEKIT_API_KEY=your_api_key\nLIVEKIT_API_SECRET=your_api_secret\n",
      "utf8"
    );
    await dialog.showMessageBox({
      type: "info",
      title: "Первый запуск Алло",
      message: "Приложение установлено. Чтобы заработали видеозвонки, нужно один раз подключить LiveKit.",
      detail: `Сейчас откроется файл настроек. Заполните в нём LIVEKIT_URL, LIVEKIT_API_KEY и LIVEKIT_API_SECRET. Путь к файлу: ${configPath}`,
      buttons: ["Открыть файл настроек", "Позже"]
    }).then(({ response }) => {
      if (response === 0) shell.openPath(configPath);
    });
  }
  dotenv.config({ path: configPath, override: true });
}

async function createWindow() {
  await loadUserConfig();
  // Порт выбирается автоматически, чтобы не конфликтовать с другими программами.
  localServer = await startServer(0);
  const address = localServer.address();
  const appUrl = `http://127.0.0.1:${address.port}`;

  mainWindow = new BrowserWindow({
    width: 1440,
    height: 920,
    minWidth: 900,
    minHeight: 650,
    title: "Высший уровень: Алло",
    backgroundColor: "#111116",
    autoHideMenuBar: true,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith("https://") || url.startsWith("http://")) shell.openExternal(url);
    return { action: "deny" };
  });
  await mainWindow.loadURL(appUrl);
  mainWindow.on("closed", () => { mainWindow = null; });
}

app.whenReady().then(createWindow).catch((error) => {
  console.error("Ошибка запуска Алло:", error);
  app.quit();
});

app.on("window-all-closed", () => {
  if (localServer) localServer.close();
  if (process.platform !== "darwin") app.quit();
});

app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});

app.on("before-quit", () => {
  if (localServer) localServer.close();
});
